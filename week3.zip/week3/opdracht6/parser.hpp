#ifndef _PARSER_HPP_
#define _PARSER_HPP_

#define WS_LIST_SIZE 6
#define MAX_NUM_TOKENS	255
#define MAX_TOKEN_SIZE	255

class PARSER {
	public:
		bool tokenizer(char *input, char *tokens[]);	
		
	private:
};

#endif