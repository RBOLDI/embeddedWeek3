// w3.1.3hwlayer

#ifndef _HWLAYER_HPP_
#define _HWLAYER_HPP_

  #include <bcm2835.h>
  #include <stdbool.h>
  #include <stdio.h>
  #include <string.h>
  #include <time.h>
  //threads
  #include "osthread.hpp"

#endif // _HWLAYER_HPP_